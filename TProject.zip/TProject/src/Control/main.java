package Control;

import GUI.*;

public class main {
    public static void main(String[] args){
        loginGUI test = new loginGUI();
        test.setVisible(true);
    }
}
